bash -x install-release-my.sh
\cp -f server.json  /usr/local/etc/v2ray/config.json

#wget https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh
#download_v2ray

#v2ray-linux.zip  -- 
# v2ray-linux-64.zip  ,amd64
# v2ray-linux-arm64-v8a.zip ,arm64
